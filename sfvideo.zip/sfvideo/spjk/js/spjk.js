var ip; 
$(function(){
	ip = GetRequest().ip;
	CreatePlugin();
	loginDevice(ip);
	ConnectVideo(ip);
});

	var plugin;
	var ptzEnable = false;
	
	//登陆信息   视频设备登录信息
	var rs = {
			ip:'192.168.1.211',
			port:80,
			username:'admin',
			password:'ncsk123456'
	};
	
	//判断浏览器类型  是否为IE浏览器
	var isIE = /(msie\s|trident.*rv:)([\w.]+)/.exec(navigator.userAgent.toLowerCase()) !=null? true : false;
	//注册插件，创建对象
	function CreatePlugin()
	{
		if(isIE)
		{
			plugin = document.getElementById("ocx").CreatePlugin();
			SetVideoWndNum(16);
			changeWndNum(1);
		}
		else
		{
			plugin = document.getElementById("ocx");
			SetVideoWndNum(16);
			changeWndNum(1);
		}
	}
	//登录设备
	function loginDevice(ip)
	{
		rs.ip = ip;
		var r = plugin.LoginDevice(rs.ip, rs.port, rs.username, rs.password,rs.port);
	}
	//退出设备
	function logoutDevice(ip)
	{
		plugin.LogoutDevice(ip);
	}
	//链接视频
	function ConnectVideo(ip)
	{
		rs.ip = ip;
		var r = plugin.ConnectRealVideo(rs.ip,0,0,0);
	}
	//退出当前视频
	function DisConnectVideo(ip)
	{
		rs.ip = ip;
	    var r = plugin.DisConnectRealVideo(rs.ip,0,0);
	}
	//设置分频  
	function SetVideoWndNum(num){
		plugin.SetMultiScreenNodeNum(num);
	}
	//改变分频数量
	var windNum = 1;
	function changeWndNum(num){
		plugin.SetSpitNum(num);
		windNum = num;
	}
	//开启云台控制操作
	function StartPTZ(code)
	{
		plugin.StartPTZ(code,5,5,0);
	}
	//停止云台控制操作
	function StopPTZ(code)
	{
		plugin.StopPTZ(code,5,5,0);
	}
	//激活云台三维定位功能
	function PtzLocate()
	{
		ptzEnable = plugin.ActivePTZLocate(ptzEnable?false:true);
	}
	//抓图
	function CrabOnePicture()
	{
		plugin.SetStoragePath("LiveSnapshot","D:\\dh\\pictrue\\");
		var result = plugin.CrabOnePicture(1,"LiveSnapshot",true);
		if(!result){
			alert("抓图失败！");
		}
	}
	//录像
	function OpenRecordVideo(id)
	{
		var sta = $('#'+id).val();
		var flag = false;
		if(sta = '录像'){
			flag = true;
			plugin.SetStoragePath("LiveSnapshot","D:\\dh\\pictrue\\");
			$('#'+id).val("停止");
		}else{
			flag = false;
			$('#'+id).val("录像");
		}
		var result = plugin.ControlRecordingVideo(0,"LiveRecord",flag);
		if(result){
			alert("录像失败！");
		}
	}