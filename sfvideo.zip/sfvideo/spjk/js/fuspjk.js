/*$(function(){
	CreatePlugin();
	var ip = GetRequest().ip;
	loginDevice(ip);
	ConnectVideo(ip);
});*/

	var plugin;
	var ptzEnable = false;
	
	var tl = {
		"UserName": "UserName",
		"Password": "Password",
		"Port": "Port",
		"Sign In": "登录",
		"Sign Out": "退出"
	};
	
	//判断浏览器类型  是否为IE浏览器
	var isIE = /(msie\s|trident.*rv:)([\w.]+)/.exec(navigator.userAgent.toLowerCase()) !=null? true : false;
	//注册插件，创建对象
	function CreatePlugin()
	{
		if(isIE)
		{
			//document.getElementById("ocx").AddEventListener("FileDialogInfo",ResponseSetStoragePath);
			plugin = document.getElementById("ocx").CreatePlugin();
		}
		else
		{
			plugin = document.getElementById("ocx");
		}
	}
	//登录设备
	function loginDevice(self)
	{
	    var rs = getCurrentData(self);
		var r = plugin.LoginDevice('192.168.1.210', 80, 'admin', 'ncsk123456',80);
		if(0 == r)
		{
			var subNode = "<option value=" + rs.ip + ">" + rs.ip + "</option>";
			$("#deviceList").append(subNode);
			$("#deviceList").val(rs.ip);
		}
	}
	//退出设备
	function logoutDevice(self)
	{
		//var selectDevice = $("#deviceList").find("option:selected").text();
		plugin.LogoutDevice(selectDevice);
		//$("#deviceList option[value='" + selectDevice + "']").remove();
	}
	
	//链接视频
	function ConnectVideo()
	{
	    //获得选中的设备IP
		var selectDevice = $("#deviceList").find("option:selected").text();
		var r = plugin.ConnectRealVideo(selectDevice,0,0,0);
	}
	//退出当前视频
	function DisConnectVideo()
	{
		//setCurDevice();
	    var selectDevice = $("#deviceList").find("option:selected").text();
	    var r = plugin.DisConnectRealVideo(selectDevice,0,0);
	}
	//开启云台控制操作
	function StartPTZ(code)
	{
	    //var step = parseInt(document.getElementById("step").value);
		plugin.StartPTZ(code,5,5,0);
	}
	//停止云台控制操作
	function StopPTZ(code)
	{
	    //var step = parseInt(document.getElementById("step").value);
		plugin.StopPTZ(code,5,5,0);
	}
	//激活云台三维定位功能
	function PtzLocate()
	{
		ptzEnable = plugin.ActivePTZLocate(ptzEnable?false:true);
	}
	
	//抓图
	function CrabOnePicture()
	{
		plugin.SetStoragePath("LiveSnapshot","D:\\dh\\pictrue\\");
		plugin.CrabOnePicture(1,"LiveSnapshot",true);
	}
	//录像
	//录像
	function OpenRecordVideo(id)
	{
		var sta = $('#'+id).val();
		var flag = false;
		if(sta = '录像'){
			flag = true;
			plugin.SetStoragePath("LiveSnapshot","D:\\dh\\pictrue\\");
			$('#'+id).val("停止");
		}else{
			flag = false;
			$('#'+id).val("录像");
		}
		var result = plugin.ControlRecordingVideo(0,"LiveRecord",flag);
		if(result){
			alert("录像失败！");
		}
	}
	//切换分屏数量
	function SwitchWndNum()
	{
	    var num = parseInt(document.getElementById("wndNum").value);
		plugin.SetSpitNum(num);
	}
	
	function getCurrentData(self){
	    var t = $(self);
	    var ts = t.parent().find('input');
	    var rs = {};
	    rs.ip = ts[0].value;
	    rs.port = ts[1].value - 0;
	    rs.username = ts[2].value;
	    rs.password = ts[3].value;
	    return rs;
	}
	
	var inhtml = '<div>';
	inhtml = inhtml + 'ip:<input size="10" />';
	inhtml = inhtml + tl["Port"] + ':<input size="5" value="80" />';
	inhtml = inhtml + tl["UserName"] + ':<input  size="5" value="admin" />';
	inhtml = inhtml + tl["Password"] + ':<input type="password" size="5" value="admin"/>';
	inhtml = inhtml + '<input type="button" size="10" onClick="loginDevice(this)" value=' + tl["Sign In"] + '>';
	inhtml = inhtml + '<input type="button" size="10" onClick="logoutDevice(this)" value=' + tl["Sign Out"] + '>';
	inhtml = inhtml + '</div>';
	
	function SetVideoWndNum()
	{
	    var num = $('#videoNum').val() - 0;
		var r = plugin.SetMultiScreenNodeNum(num || 1);//设置分频数量
	    var domNum = $('#main div').length;
	    if(domNum > num){
	        $('#main div:gt(' + (num - 1) + ')').remove();
	        return;
	    }
	    for(var i = domNum ;i < num ; i++){
	        $('#main').append(inhtml);
	    }
	}